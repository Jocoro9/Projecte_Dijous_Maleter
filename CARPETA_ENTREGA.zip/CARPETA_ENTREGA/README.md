View this project on [CADLAB.io](https://cadlab.io/project/29047). 

Aquest projecte conté els elements necessaris per la fabricació de una PCB que gestiona un maletero.

# Projecte_Dijous_Maleter